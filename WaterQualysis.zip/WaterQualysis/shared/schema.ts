import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const heavyMetalStandards = pgTable("heavy_metal_standards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  whoLimit: real("who_limit").notNull(),
  bisLimit: real("bis_limit").notNull(),
  healthImpact: text("health_impact").notNull(),
});

export const waterTestResults = pgTable("water_test_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sampleId: text("sample_id").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  metalConcentrations: jsonb("metal_concentrations").notNull(), // {Pb: 0.020, Cd: 0.004, ...}
  hmpiScore: real("hmpi_score"),
  pollutionLevel: text("pollution_level"),
  safetyStatus: text("safety_status"),
  calculationDetails: jsonb("calculation_details"), // Store Qi, Wi values etc.
});

// Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertHeavyMetalStandardSchema = createInsertSchema(heavyMetalStandards).omit({
  id: true,
});

export const insertWaterTestResultSchema = createInsertSchema(waterTestResults).omit({
  id: true,
  uploadedAt: true,
});

// File upload schema
export const fileUploadSchema = z.object({
  file: z.instanceof(File),
  sampleIds: z.array(z.string()).optional(),
});

// HMPI calculation result schema
export const hmpiCalculationSchema = z.object({
  sampleId: z.string(),
  metals: z.record(z.object({
    concentration: z.number(),
    standardLimit: z.number(),
    qualityRating: z.number(),
    weight: z.number(),
    status: z.enum(['safe', 'exceeded']),
  })),
  hmpiScore: z.number(),
  pollutionLevel: z.string(),
  safetyStatus: z.string(),
  recommendations: z.array(z.string()),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type HeavyMetalStandard = typeof heavyMetalStandards.$inferSelect;
export type InsertHeavyMetalStandard = z.infer<typeof insertHeavyMetalStandardSchema>;
export type WaterTestResult = typeof waterTestResults.$inferSelect;
export type InsertWaterTestResult = z.infer<typeof insertWaterTestResultSchema>;
export type HMPICalculation = z.infer<typeof hmpiCalculationSchema>;

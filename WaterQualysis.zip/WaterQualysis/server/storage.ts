import { users, heavyMetalStandards, waterTestResults, type User, type InsertUser, type HeavyMetalStandard, type InsertHeavyMetalStandard, type WaterTestResult, type InsertWaterTestResult } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Heavy Metal Standards
  getAllStandards(): Promise<HeavyMetalStandard[]>;
  getStandardBySymbol(symbol: string): Promise<HeavyMetalStandard | undefined>;
  createStandard(standard: InsertHeavyMetalStandard): Promise<HeavyMetalStandard>;
  
  // Water Test Results
  createWaterTestResult(result: InsertWaterTestResult): Promise<WaterTestResult>;
  getWaterTestResult(id: string): Promise<WaterTestResult | undefined>;
  getAllWaterTestResults(): Promise<WaterTestResult[]>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize WHO/BIS standards from the PDF
    this.initializeStandards();
  }

  private async initializeStandards() {
    const defaultStandards: InsertHeavyMetalStandard[] = [
      {
        symbol: "Pb",
        name: "Lead",
        whoLimit: 0.010,
        bisLimit: 0.010,
        healthImpact: "Neurological damage, kidney problems"
      },
      {
        symbol: "Cd",
        name: "Cadmium",
        whoLimit: 0.003,
        bisLimit: 0.003,
        healthImpact: "Kidney damage, bone disease"
      },
      {
        symbol: "As",
        name: "Arsenic",
        whoLimit: 0.010,
        bisLimit: 0.010,
        healthImpact: "Cancer, skin lesions"
      },
      {
        symbol: "Cr",
        name: "Chromium",
        whoLimit: 0.050,
        bisLimit: 0.050,
        healthImpact: "Skin irritation, liver damage"
      },
      {
        symbol: "Hg",
        name: "Mercury",
        whoLimit: 0.001,
        bisLimit: 0.001,
        healthImpact: "Neurological disorders, kidney damage"
      },
      {
        symbol: "Fe",
        name: "Iron",
        whoLimit: 0.300,
        bisLimit: 0.300,
        healthImpact: "Gastrointestinal issues"
      },
      {
        symbol: "Zn",
        name: "Zinc",
        whoLimit: 3.000,
        bisLimit: 5.000,
        healthImpact: "Gastrointestinal irritation"
      },
      {
        symbol: "Cu",
        name: "Copper",
        whoLimit: 2.000,
        bisLimit: 0.050,
        healthImpact: "Gastrointestinal effects"
      },
      {
        symbol: "Ni",
        name: "Nickel",
        whoLimit: 0.070,
        bisLimit: 0.020,
        healthImpact: "Allergic reactions, lung damage"
      },
      {
        symbol: "Mn",
        name: "Manganese",
        whoLimit: 0.400,
        bisLimit: 0.100,
        healthImpact: "Neurological effects"
      }
    ];

    for (const standard of defaultStandards) {
      try {
        await this.createStandard(standard);
      } catch (error) {
        // Standard might already exist, continue
      }
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllStandards(): Promise<HeavyMetalStandard[]> {
    return await db.select().from(heavyMetalStandards);
  }

  async getStandardBySymbol(symbol: string): Promise<HeavyMetalStandard | undefined> {
    const [standard] = await db.select().from(heavyMetalStandards).where(eq(heavyMetalStandards.symbol, symbol));
    return standard || undefined;
  }

  async createStandard(insertStandard: InsertHeavyMetalStandard): Promise<HeavyMetalStandard> {
    const [standard] = await db
      .insert(heavyMetalStandards)
      .values(insertStandard)
      .returning();
    return standard;
  }

  async createWaterTestResult(insertResult: InsertWaterTestResult): Promise<WaterTestResult> {
    const [result] = await db
      .insert(waterTestResults)
      .values(insertResult)
      .returning();
    return result;
  }

  async getWaterTestResult(id: string): Promise<WaterTestResult | undefined> {
    const [result] = await db.select().from(waterTestResults).where(eq(waterTestResults.id, id));
    return result || undefined;
  }

  async getAllWaterTestResults(): Promise<WaterTestResult[]> {
    return await db.select().from(waterTestResults);
  }
}

export const storage = new DatabaseStorage();

import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import * as XLSX from "xlsx";
// PDF parsing will be imported dynamically to avoid startup issues
import { z } from "zod";
import { hmpiCalculationSchema } from "@shared/schema";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all heavy metal standards
  app.get("/api/standards", async (req, res) => {
    try {
      const standards = await storage.getAllStandards();
      res.json(standards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch standards" });
    }
  });

  // Upload and process water test file
  app.post("/api/upload", upload.single('file'), async (req: MulterRequest, res) => {
    try {
      console.log('File upload request received:', {
        hasFile: !!req.file,
        filename: req.file?.originalname,
        size: req.file?.size,
        mimetype: req.file?.mimetype
      });
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const fileBuffer = req.file.buffer;
      const filename = req.file.originalname;
      let data: any[][] = [];

      // Parse file based on extension
      if (filename.endsWith('.csv')) {
        const csvText = fileBuffer.toString('utf8');
        data = parseCSV(csvText);
      } else if (filename.endsWith('.xlsx') || filename.endsWith('.xls')) {
        const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        data = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      } else if (filename.endsWith('.pdf')) {
        const pdfParse = (await import('pdf-parse')).default;
        const pdfData = await pdfParse(fileBuffer);
        data = parsePDFTable(pdfData.text);
      } else {
        return res.status(400).json({ message: "Unsupported file format. Please upload CSV, Excel, or PDF files." });
      }

      if (data.length < 2) {
        return res.status(400).json({ message: "File must contain header row and at least one data row" });
      }

      // Process the data
      const headers = data[0] as string[];
      const rows = data.slice(1);
      
      // Validate headers contain required metals
      const requiredMetals = ['Pb', 'Cd', 'As', 'Cr', 'Hg'];
      const missingMetals = requiredMetals.filter(metal => !headers.includes(metal));
      
      if (missingMetals.length > 0) {
        return res.status(400).json({ 
          message: `Missing required metal columns: ${missingMetals.join(', ')}` 
        });
      }

      // Calculate HMPI for each row
      const results = [];
      const standards = await storage.getAllStandards();
      
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const sampleId = row[0]?.toString() || `Sample_${i + 1}`;
        
        // Extract metal concentrations
        const metalConcentrations: Record<string, number> = {};
        for (let j = 1; j < headers.length; j++) {
          const metalSymbol = headers[j];
          const concentration = parseFloat(row[j]?.toString() || '0');
          if (!isNaN(concentration)) {
            metalConcentrations[metalSymbol] = concentration;
          }
        }

        // Calculate HMPI
        const hmpiResult = calculateHMPI(metalConcentrations, standards);
        
        // Store result
        const waterTestResult = await storage.createWaterTestResult({
          sampleId,
          metalConcentrations,
          hmpiScore: hmpiResult.hmpiScore,
          pollutionLevel: hmpiResult.pollutionLevel,
          safetyStatus: hmpiResult.safetyStatus,
          calculationDetails: hmpiResult.metals
        });

        results.push({ ...hmpiResult, id: waterTestResult.id });
      }

      res.json({ 
        message: "File processed successfully",
        results,
        totalSamples: results.length
      });

    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Failed to process file" });
    }
  });

  // Get calculation results
  app.get("/api/results/:id", async (req, res) => {
    try {
      const result = await storage.getWaterTestResult(req.params.id);
      if (!result) {
        return res.status(404).json({ message: "Result not found" });
      }
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch result" });
    }
  });

  // Get all results
  app.get("/api/results", async (req, res) => {
    try {
      const results = await storage.getAllWaterTestResults();
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch results" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function parseCSV(csvText: string): string[][] {
  const lines = csvText.split('\n').filter(line => line.trim());
  return lines.map(line => {
    const values = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    values.push(current.trim());
    return values;
  });
}

function parsePDFTable(pdfText: string): string[][] {
  // Simple PDF table parsing - looks for table-like structures
  const lines = pdfText.split('\n').filter(line => line.trim());
  const data: string[][] = [];
  
  for (const line of lines) {
    // Look for lines that contain metal symbols and numbers
    if (line.match(/\b(Pb|Cd|As|Cr|Hg|Fe|Zn|Cu|Ni|Mn)\b/) && line.match(/\d+\.\d+/)) {
      // Split by whitespace and filter out empty strings
      const parts = line.split(/\s+/).filter(part => part.trim());
      if (parts.length >= 2) {
        data.push(parts);
      }
    }
  }
  
  // If we found data, try to create a proper header row
  if (data.length > 0) {
    const header = ['Sample_ID', 'Pb', 'Cd', 'As', 'Cr', 'Hg', 'Fe', 'Zn', 'Cu', 'Ni', 'Mn'];
    const processedData = [header];
    
    // Process each found line and try to extract metal concentrations
    data.forEach((row, index) => {
      const sampleRow = [`Sample_${index + 1}`];
      header.slice(1).forEach(metal => {
        // Look for the metal value in the row
        const metalIndex = row.findIndex(part => part.includes(metal));
        if (metalIndex >= 0 && metalIndex + 1 < row.length) {
          sampleRow.push(row[metalIndex + 1]);
        } else {
          sampleRow.push('0');
        }
      });
      processedData.push(sampleRow);
    });
    
    return processedData;
  }
  
  throw new Error('No valid table data found in PDF');
}

function calculateHMPI(metalConcentrations: Record<string, number>, standards: any[]): any {
  const metals: Record<string, any> = {};
  let sumWiQi = 0;
  let sumWi = 0;

  // Calculate for each metal
  for (const [symbol, concentration] of Object.entries(metalConcentrations)) {
    const standard = standards.find(s => s.symbol === symbol);
    if (!standard) continue;

    const standardLimit = Math.min(standard.whoLimit, standard.bisLimit); // Use stricter limit
    const qualityRating = (concentration / standardLimit) * 100;
    const weight = 1 / standardLimit;
    const status = qualityRating <= 100 ? 'safe' : 'exceeded';

    metals[symbol] = {
      concentration,
      standardLimit,
      qualityRating: Math.round(qualityRating * 100) / 100,
      weight: Math.round(weight * 100) / 100,
      status
    };

    sumWiQi += weight * qualityRating;
    sumWi += weight;
  }

  // Calculate final HMPI
  const hmpiScore = Math.round((sumWiQi / sumWi) * 100) / 100;
  
  // Determine pollution level and safety status
  let pollutionLevel = '';
  let safetyStatus = '';
  let recommendations: string[] = [];

  if (hmpiScore < 25) {
    pollutionLevel = 'No pollution';
    safetyStatus = 'Safe for drinking';
    recommendations = ['Normal chlorination & disinfection', 'Suitable for all uses'];
  } else if (hmpiScore < 50) {
    pollutionLevel = 'Low pollution';
    safetyStatus = 'Generally safe (monitoring needed)';
    recommendations = ['Regular monitoring', 'Simple filtration/UV treatment', 'Drinking with caution'];
  } else if (hmpiScore < 75) {
    pollutionLevel = 'Medium pollution';
    safetyStatus = 'Not preferable for drinking';
    recommendations = ['Advanced filtration (RO, activated carbon)', 'Ion exchange treatment', 'Suitable for irrigation'];
  } else if (hmpiScore < 100) {
    pollutionLevel = 'High pollution';
    safetyStatus = 'Unsafe for drinking';
    recommendations = ['Heavy metal removal (RO, electrocoagulation)', 'Nanofiltration required', 'Limited industrial use only'];
  } else {
    pollutionLevel = 'Critical pollution';
    safetyStatus = 'Completely unsafe';
    recommendations = ['Strict restriction', 'Only for non-contact purposes', 'Industrial use only'];
  }

  return {
    sampleId: '',
    metals,
    hmpiScore,
    pollutionLevel,
    safetyStatus,
    recommendations
  };
}

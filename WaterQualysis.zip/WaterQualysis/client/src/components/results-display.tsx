import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { HMPICalculation } from "@shared/schema";
import { FileText, Download, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ResultsDisplayProps {
  result: HMPICalculation;
  allResults: HMPICalculation[];
  onResultSelect: (result: HMPICalculation) => void;
}

export function ResultsDisplay({ result, allResults, onResultSelect }: ResultsDisplayProps) {
  const { toast } = useToast();

  const getPollutionLevelColor = (hmpiScore: number) => {
    if (hmpiScore < 25) return "bg-success/10 text-success border-success/20";
    if (hmpiScore < 50) return "bg-success/20 text-success border-success/30";
    if (hmpiScore < 75) return "bg-warning/20 text-warning border-warning/30";
    if (hmpiScore < 100) return "bg-destructive/20 text-destructive border-destructive/30";
    return "bg-destructive/30 text-destructive border-destructive/40";
  };

  const getMetalStatusIcon = (status: string) => {
    return status === 'safe' ? 
      <CheckCircle className="h-4 w-4 text-success" /> : 
      <XCircle className="h-4 w-4 text-destructive" />;
  };

  const getMetalStatusBadge = (status: string) => {
    return status === 'safe' ? 
      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
        <CheckCircle className="mr-1 h-3 w-3" />
        Safe
      </Badge> : 
      <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
        <XCircle className="mr-1 h-3 w-3" />
        Exceeded
      </Badge>;
  };

  const handleExport = (format: string) => {
    // Create export data
    const exportData = {
      sampleId: result.sampleId,
      hmpiScore: result.hmpiScore,
      pollutionLevel: result.pollutionLevel,
      safetyStatus: result.safetyStatus,
      recommendations: result.recommendations,
      metals: result.metals,
      timestamp: new Date().toISOString()
    };

    if (format === 'json') {
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `hmpi-result-${result.sampleId}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else if (format === 'csv') {
      const metalRows = Object.entries(result.metals).map(([symbol, data]) => 
        `${symbol},${data.concentration},${data.standardLimit},${data.qualityRating},${data.weight},${data.status}`
      ).join('\n');
      
      const csvContent = [
        'Sample ID,HMPI Score,Pollution Level,Safety Status',
        `${result.sampleId},${result.hmpiScore},${result.pollutionLevel},${result.safetyStatus}`,
        '',
        'Metal,Concentration,Standard Limit,Quality Rating,Weight,Status',
        metalRows
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `hmpi-result-${result.sampleId}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    }

    toast({
      title: "Export successful",
      description: `Results exported as ${format.toUpperCase()}`,
    });
  };

  return (
    <Card className="shadow-lg border border-border">
      <div className="p-6 border-b border-border">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-2xl font-bold text-foreground mb-2">HMPI Calculation Results</h3>
            <p className="text-muted-foreground">Detailed analysis of heavy metal pollution index</p>
          </div>
          {allResults.length > 1 && (
            <div className="min-w-48">
              <Select value={result.sampleId} onValueChange={(value) => {
                const selectedResult = allResults.find(r => r.sampleId === value);
                if (selectedResult) onResultSelect(selectedResult);
              }}>
                <SelectTrigger data-testid="select-sample">
                  <SelectValue placeholder="Select sample" />
                </SelectTrigger>
                <SelectContent>
                  {allResults.map((r) => (
                    <SelectItem key={r.sampleId} value={r.sampleId}>
                      {r.sampleId} (HMPI: {r.hmpiScore})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </div>
      
      <CardContent className="p-6">
        {/* Overall HMPI Score */}
        <div className="mb-8">
          <div className={`rounded-lg p-6 text-white mb-4 ${
            result.hmpiScore < 25 ? 'bg-gradient-to-r from-success to-success' :
            result.hmpiScore < 50 ? 'bg-gradient-to-r from-success to-warning' :
            result.hmpiScore < 75 ? 'bg-gradient-to-r from-warning to-warning' :
            result.hmpiScore < 100 ? 'bg-gradient-to-r from-warning to-destructive' :
            'bg-gradient-to-r from-destructive to-destructive'
          }`}>
            <div className="text-center">
              <h4 className="text-lg font-semibold mb-2">Heavy Metal Pollution Index</h4>
              <div className="text-4xl font-bold mb-2" data-testid="hmpi-score">{result.hmpiScore}</div>
              <div className="text-sm opacity-90">{result.pollutionLevel} - {result.safetyStatus}</div>
            </div>
          </div>
          
          {/* Safety Recommendations */}
          <div className={`border rounded-lg p-4 ${
            result.hmpiScore >= 75 ? 'bg-destructive/10 border-destructive/20' : 
            result.hmpiScore >= 50 ? 'bg-warning/10 border-warning/20' :
            'bg-success/10 border-success/20'
          }`}>
            <h5 className={`font-semibold mb-2 flex items-center ${
              result.hmpiScore >= 75 ? 'text-destructive' :
              result.hmpiScore >= 50 ? 'text-warning' :
              'text-success'
            }`}>
              <AlertTriangle className="mr-2 h-4 w-4" />
              Safety Recommendations
            </h5>
            <ul className="text-sm text-foreground space-y-1">
              {result.recommendations.map((rec, idx) => (
                <li key={idx}>• {rec}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Individual Metal Analysis */}
        <div className="mb-8">
          <h4 className="text-xl font-bold text-foreground mb-4">Individual Heavy Metal Analysis</h4>
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="metals-analysis-table">
              <thead className="bg-muted">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Metal</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Concentration</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Standard Limit</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Quality Rating (Qᵢ)</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Weight (Wᵢ)</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {Object.entries(result.metals).map(([symbol, data]) => (
                  <tr key={symbol} data-testid={`metal-row-${symbol}`}>
                    <td className="px-4 py-3 font-medium flex items-center">
                      {getMetalStatusIcon(data.status)}
                      <span className="ml-2">{symbol}</span>
                    </td>
                    <td className="px-4 py-3 font-mono">{data.concentration.toFixed(4)}</td>
                    <td className="px-4 py-3 font-mono">{data.standardLimit.toFixed(3)}</td>
                    <td className="px-4 py-3 font-mono">{data.qualityRating.toFixed(2)}</td>
                    <td className="px-4 py-3 font-mono">{data.weight.toFixed(2)}</td>
                    <td className="px-4 py-3">
                      {getMetalStatusBadge(data.status)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* HMPI Classification */}
        <div className="mb-8">
          <h4 className="text-xl font-bold text-foreground mb-4">HMPI Classification Guide</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { range: "< 25", level: "Safe", description: "No pollution - Safe for drinking", color: "success" },
              { range: "25-50", level: "Low Pollution", description: "Generally safe with monitoring", color: "success" },
              { range: "50-75", level: "Medium Pollution", description: "Advanced filtration required", color: "warning" },
              { range: "75-100", level: "High Pollution", description: "Heavy metal removal needed", color: "destructive" },
              { range: "≥ 100", level: "Critical", description: "Completely unsafe for drinking", color: "destructive" }
            ].map((item, idx) => (
              <div key={idx} className={`border rounded-lg p-4 ${
                item.color === 'success' ? 'bg-success/10 border-success/20' :
                item.color === 'warning' ? 'bg-warning/20 border-warning/30' :
                'bg-destructive/20 border-destructive/30'
              } ${
                (result.hmpiScore < 25 && item.range === "< 25") ||
                (result.hmpiScore >= 25 && result.hmpiScore < 50 && item.range === "25-50") ||
                (result.hmpiScore >= 50 && result.hmpiScore < 75 && item.range === "50-75") ||
                (result.hmpiScore >= 75 && result.hmpiScore < 100 && item.range === "75-100") ||
                (result.hmpiScore >= 100 && item.range === "≥ 100")
                ? 'ring-2 ring-primary' : ''
              }`}>
                <h5 className={`font-semibold mb-2 ${
                  item.color === 'success' ? 'text-success' :
                  item.color === 'warning' ? 'text-warning' :
                  'text-destructive'
                }`}>
                  {item.level} ({item.range})
                </h5>
                <p className="text-sm text-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Export Options */}
        <div className="border-t border-border pt-6">
          <h4 className="text-lg font-semibold text-foreground mb-4">Export Results</h4>
          <div className="flex flex-wrap gap-3">
            <Button 
              onClick={() => handleExport('json')}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="button-export-json"
            >
              <FileText className="mr-2 h-4 w-4" />
              Export JSON Report
            </Button>
            <Button 
              onClick={() => handleExport('csv')}
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90"
              data-testid="button-export-csv"
            >
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

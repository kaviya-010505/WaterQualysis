import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { HeavyMetalStandard } from "@shared/schema";

export function StandardsTable() {
  const { data: standards, isLoading, error } = useQuery<HeavyMetalStandard[]>({
    queryKey: ['/api/standards'],
  });

  if (isLoading) {
    return (
      <Card className="shadow-lg border border-border">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/4"></div>
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="shadow-lg border border-border">
        <CardContent className="p-6">
          <p className="text-destructive">Failed to load standards data</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg border border-border">
      <div className="p-6 border-b border-border">
        <h3 className="text-2xl font-bold text-foreground mb-2">WHO/BIS Permissible Limits</h3>
        <p className="text-muted-foreground">Standard permissible limits for heavy metals in drinking water</p>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full" data-testid="standards-table">
          <thead className="bg-muted">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Heavy Metal</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Symbol</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">WHO Limit (mg/L)</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">BIS Limit (mg/L)</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Health Impact</th>
            </tr>
          </thead>
          <tbody className="bg-card divide-y divide-border">
            {standards?.map((standard) => (
              <tr key={standard.id} data-testid={`standard-row-${standard.symbol}`}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">
                  {standard.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                  <Badge variant="outline">{standard.symbol}</Badge>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-mono">
                  {standard.whoLimit.toFixed(3)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground font-mono">
                  {standard.bisLimit.toFixed(3)}
                </td>
                <td className="px-6 py-4 text-sm">
                  <span className={getHealthImpactColor(standard.healthImpact)}>
                    {standard.healthImpact}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function getHealthImpactColor(impact: string): string {
  if (impact.toLowerCase().includes('cancer') || impact.toLowerCase().includes('neurological')) {
    return 'text-destructive';
  } else if (impact.toLowerCase().includes('kidney') || impact.toLowerCase().includes('damage')) {
    return 'text-destructive';
  } else if (impact.toLowerCase().includes('irritation') || impact.toLowerCase().includes('gastrointestinal')) {
    return 'text-warning';
  }
  return 'text-muted-foreground';
}

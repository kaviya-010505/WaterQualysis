import { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileSpreadsheet, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { HMPICalculation } from "@shared/schema";

interface FileUploadProps {
  onCalculationStart: () => void;
  onFileProcessed: (results: HMPICalculation[]) => void;
}

export function FileUpload({ onCalculationStart, onFileProcessed }: FileUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFile = async (file: File) => {
    if (!file) return;

    // Validate file type
    const validTypes = ['.csv', '.xlsx', '.xls', '.pdf'];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!validTypes.includes(fileExtension)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV, Excel, or PDF file (.csv, .xlsx, .xls, .pdf)",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    onCalculationStart();

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await apiRequest('POST', '/api/upload', formData);
      const data = await response.json();

      if (data.results && data.results.length > 0) {
        onFileProcessed(data.results);
        toast({
          title: "File processed successfully",
          description: `Calculated HMPI for ${data.totalSamples} sample(s)`,
        });
      } else {
        throw new Error("No results returned from calculation");
      }
    } catch (error: any) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error.message || "Failed to process file. Please check the format and try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card className="shadow-lg border border-border">
      <div className="p-6 border-b border-border">
        <h3 className="text-2xl font-bold text-foreground mb-2">Upload Water Test Data</h3>
        <p className="text-muted-foreground">Upload your CSV or Excel file containing heavy metal concentration data</p>
      </div>
      
      <CardContent className="p-6">
        <div 
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
            dragActive 
              ? 'border-primary bg-primary/5' 
              : 'border-border hover:border-primary'
          } ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={openFileDialog}
          data-testid="file-drop-zone"
        >
          {isUploading ? (
            <div className="flex flex-col items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
              <h4 className="text-lg font-semibold mb-2">Processing file...</h4>
              <p className="text-muted-foreground">Calculating HMPI values</p>
            </div>
          ) : (
            <>
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h4 className="text-lg font-semibold mb-2">Drop files here or click to browse</h4>
              <p className="text-muted-foreground mb-4">Supports CSV, Excel (.xlsx, .xls), and PDF files up to 10MB</p>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-select-file">
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Select File
              </Button>
            </>
          )}
        </div>
        
        <Input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept=".csv,.xlsx,.xls,.pdf"
          onChange={handleFileSelect}
          data-testid="input-file"
        />
        
        {/* Sample File Format Guide */}
        <div className="mt-6 bg-accent rounded-lg p-4">
          <h5 className="font-semibold mb-2 flex items-center">
            <AlertCircle className="text-primary mr-2 h-4 w-4" />
            Expected File Format
          </h5>
          <div className="text-sm text-muted-foreground">
            <p className="mb-2">Your file should contain columns for each heavy metal concentration (mg/L):</p>
            <div className="bg-background rounded border p-3 font-mono text-xs overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr>
                    <th className="pr-4">Sample_ID</th>
                    <th className="pr-4">Pb</th>
                    <th className="pr-4">Cd</th>
                    <th className="pr-4">As</th>
                    <th className="pr-4">Cr</th>
                    <th className="pr-4">Hg</th>
                    <th className="pr-4">Fe</th>
                    <th className="pr-4">Zn</th>
                    <th className="pr-4">Cu</th>
                    <th className="pr-4">Ni</th>
                    <th>Mn</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="pr-4">Sample_01</td>
                    <td className="pr-4">0.020</td>
                    <td className="pr-4">0.004</td>
                    <td className="pr-4">0.005</td>
                    <td className="pr-4">0.080</td>
                    <td className="pr-4">0.0005</td>
                    <td className="pr-4">0.1</td>
                    <td className="pr-4">0.5</td>
                    <td className="pr-4">0.02</td>
                    <td className="pr-4">0.01</td>
                    <td>0.05</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="mt-2 text-xs">
              <strong>Note:</strong> At minimum, include Pb, Cd, As, Cr, and Hg columns for accurate HMPI calculation.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

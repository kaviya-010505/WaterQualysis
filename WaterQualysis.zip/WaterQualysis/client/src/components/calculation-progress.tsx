import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";

export function CalculationProgress() {
  return (
    <Card className="shadow-lg border border-border">
      <div className="p-6 border-b border-border">
        <h3 className="text-2xl font-bold text-foreground mb-2">HMPI Calculation Progress</h3>
        <p className="text-muted-foreground">Following the 4-step HMPI calculation methodology</p>
      </div>
      
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Step 1 */}
          <div className="flex items-start space-x-4" data-testid="calculation-step-1">
            <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold">
              <CheckCircle className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground mb-2">Calculate Quality Rating (Qᵢ)</h4>
              <p className="text-muted-foreground text-sm mb-3">Qᵢ = (Cᵢ / Sᵢ) × 100 for each heavy metal</p>
              <div className="bg-accent rounded-lg p-3">
                <div className="text-xs text-muted-foreground">
                  Quality rating shows pollution level as percentage of safe standard
                </div>
              </div>
            </div>
          </div>
          
          {/* Step 2 */}
          <div className="flex items-start space-x-4" data-testid="calculation-step-2">
            <div className="flex-shrink-0 w-8 h-8 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center text-sm font-bold">
              <CheckCircle className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground mb-2">Calculate Weights (Wᵢ)</h4>
              <p className="text-muted-foreground text-sm mb-3">Wᵢ = 1 / Sᵢ (inverse of permissible limit)</p>
              <div className="bg-accent rounded-lg p-3">
                <div className="text-xs text-muted-foreground">
                  More toxic metals (lower limits) get higher weights in the index
                </div>
              </div>
            </div>
          </div>
          
          {/* Step 3 */}
          <div className="flex items-start space-x-4" data-testid="calculation-step-3">
            <div className="flex-shrink-0 w-8 h-8 bg-accent text-accent-foreground rounded-full flex items-center justify-center text-sm font-bold">
              <CheckCircle className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground mb-2">Compute Numerator</h4>
              <p className="text-muted-foreground text-sm mb-3">Σ(Wᵢ × Qᵢ) for all metals</p>
              <div className="bg-accent rounded-lg p-3">
                <div className="text-xs text-muted-foreground">
                  Weighted sum combines quality ratings with metal toxicity weights
                </div>
              </div>
            </div>
          </div>
          
          {/* Step 4 */}
          <div className="flex items-start space-x-4" data-testid="calculation-step-4">
            <div className="flex-shrink-0 w-8 h-8 bg-success text-white rounded-full flex items-center justify-center text-sm font-bold">
              <CheckCircle className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground mb-2">Final HMPI</h4>
              <p className="text-muted-foreground text-sm mb-3">HMPI = Σ(Wᵢ × Qᵢ) / ΣWᵢ</p>
              <div className="bg-accent rounded-lg p-3">
                <div className="text-xs text-muted-foreground">
                  Final index provides overall pollution assessment
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

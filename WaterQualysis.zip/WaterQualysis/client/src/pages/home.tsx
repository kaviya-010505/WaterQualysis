import { useState } from "react";
import { FileUpload } from "@/components/file-upload";
import { StandardsTable } from "@/components/standards-table";
import { CalculationProgress } from "@/components/calculation-progress";
import { ResultsDisplay } from "@/components/results-display";
import { HMPICalculation } from "@shared/schema";

export default function Home() {
  const [isCalculating, setIsCalculating] = useState(false);
  const [results, setResults] = useState<HMPICalculation[]>([]);
  const [selectedResult, setSelectedResult] = useState<HMPICalculation | null>(null);

  const handleFileProcessed = (calculationResults: HMPICalculation[]) => {
    setResults(calculationResults);
    if (calculationResults.length > 0) {
      setSelectedResult(calculationResults[0]);
    }
    setIsCalculating(false);
  };

  const handleCalculationStart = () => {
    setIsCalculating(true);
    setResults([]);
    setSelectedResult(null);
  };

  return (
    <div className="bg-background text-foreground min-h-screen">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <i className="fas fa-water text-primary text-2xl mr-3"></i>
                <h1 className="text-xl font-bold text-foreground">HMPI Calculator</h1>
              </div>
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#calculator" className="text-foreground hover:text-primary transition-colors">Calculator</a>
              <a href="#standards" className="text-muted-foreground hover:text-primary transition-colors">Standards</a>
              <a href="#about" className="text-muted-foreground hover:text-primary transition-colors">About</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-secondary text-primary-foreground py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Heavy Metal Pollution Index Calculator</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto opacity-90">
            Automated HMPI calculation for groundwater contamination analysis using WHO/BIS standards. 
            Upload your water test data and get instant, accurate pollution assessment.
          </p>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <div className="flex items-center">
              <i className="fas fa-check-circle mr-2"></i>
              <span>WHO/BIS Standards</span>
            </div>
            <div className="flex items-center">
              <i className="fas fa-upload mr-2"></i>
              <span>CSV/Excel Support</span>
            </div>
            <div className="flex items-center">
              <i className="fas fa-calculator mr-2"></i>
              <span>Automated Calculations</span>
            </div>
            <div className="flex items-center">
              <i className="fas fa-download mr-2"></i>
              <span>Export Results</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* File Upload Section */}
        <section id="calculator" className="mb-12">
          <FileUpload 
            onCalculationStart={handleCalculationStart}
            onFileProcessed={handleFileProcessed}
          />
        </section>

        {/* WHO/BIS Standards Reference */}
        <section id="standards" className="mb-12">
          <StandardsTable />
        </section>

        {/* Calculation Progress */}
        {isCalculating && (
          <section className="mb-12">
            <CalculationProgress />
          </section>
        )}

        {/* Results Section */}
        {selectedResult && (
          <section className="mb-12">
            <ResultsDisplay 
              result={selectedResult}
              allResults={results}
              onResultSelect={setSelectedResult}
            />
          </section>
        )}

        {/* About Section */}
        <section id="about" className="mb-12">
          <div className="bg-card rounded-lg shadow-lg border border-border">
            <div className="p-6 border-b border-border">
              <h3 className="text-2xl font-bold text-foreground mb-2">About HMPI Calculator</h3>
              <p className="text-muted-foreground">Understanding the Heavy Metal Pollution Index methodology</p>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-foreground mb-3">What is HMPI?</h4>
                  <p className="text-muted-foreground mb-4">
                    The Heavy Metal Pollution Index (HMPI) is a comprehensive assessment tool that evaluates 
                    groundwater contamination by heavy metals. It considers both the concentration of metals 
                    and their relative toxicity to provide a single numerical value representing overall pollution level.
                  </p>
                  
                  <h4 className="text-lg font-semibold text-foreground mb-3">Calculation Method</h4>
                  <ul className="text-muted-foreground space-y-2">
                    <li><strong>Step 1:</strong> Calculate Quality Rating (Qᵢ = Cᵢ/Sᵢ × 100)</li>
                    <li><strong>Step 2:</strong> Determine Weights (Wᵢ = 1/Sᵢ)</li>
                    <li><strong>Step 3:</strong> Compute Numerator (Σ Wᵢ × Qᵢ)</li>
                    <li><strong>Step 4:</strong> Final HMPI (Σ Wᵢ × Qᵢ / Σ Wᵢ)</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold text-foreground mb-3">Key Features</h4>
                  <ul className="text-muted-foreground space-y-2">
                    <li>• Automated calculations following standard methodology</li>
                    <li>• WHO/BIS standard compliance checking</li>
                    <li>• Individual metal safety assessment</li>
                    <li>• Comprehensive reporting and export options</li>
                    <li>• Mobile-friendly interface for field use</li>
                  </ul>
                  
                  <h4 className="text-lg font-semibold text-foreground mb-3 mt-6">Applications</h4>
                  <ul className="text-muted-foreground space-y-2">
                    <li>• Environmental monitoring and assessment</li>
                    <li>• Water quality research and analysis</li>
                    <li>• Public health protection initiatives</li>
                    <li>• Policy-making and regulatory compliance</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-semibold text-foreground mb-4">HMPI Calculator</h4>
              <p className="text-muted-foreground text-sm">
                Automated heavy metal pollution index calculation for groundwater contamination analysis.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">WHO Guidelines</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">BIS Standards</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Research Papers</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">User Manual</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contact Support</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Report Issues</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Feature Requests</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-6 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 HMPI Calculator. Built for environmental research and public health protection.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { HeavyMetalStandard } from "@shared/schema";

export interface MetalData {
  concentration: number;
  standardLimit: number;
  qualityRating: number;
  weight: number;
  status: 'safe' | 'exceeded';
}

export interface HMPIResult {
  metals: Record<string, MetalData>;
  hmpiScore: number;
  pollutionLevel: string;
  safetyStatus: string;
  recommendations: string[];
}

export function calculateHMPI(
  metalConcentrations: Record<string, number>,
  standards: HeavyMetalStandard[]
): HMPIResult {
  const metals: Record<string, MetalData> = {};
  let sumWiQi = 0;
  let sumWi = 0;

  // Calculate for each metal
  for (const [symbol, concentration] of Object.entries(metalConcentrations)) {
    const standard = standards.find(s => s.symbol === symbol);
    if (!standard) continue;

    // Use the stricter limit between WHO and BIS
    const standardLimit = Math.min(standard.whoLimit, standard.bisLimit);
    
    // Step 1: Calculate Quality Rating (Qi)
    const qualityRating = (concentration / standardLimit) * 100;
    
    // Step 2: Calculate Weight (Wi)
    const weight = 1 / standardLimit;
    
    // Determine status
    const status = qualityRating <= 100 ? 'safe' : 'exceeded';

    metals[symbol] = {
      concentration,
      standardLimit,
      qualityRating: Math.round(qualityRating * 100) / 100,
      weight: Math.round(weight * 100) / 100,
      status
    };

    // Step 3: Accumulate for numerator and denominator
    sumWiQi += weight * qualityRating;
    sumWi += weight;
  }

  // Step 4: Calculate final HMPI
  const hmpiScore = Math.round((sumWiQi / sumWi) * 100) / 100;
  
  // Determine pollution level and safety status
  const { pollutionLevel, safetyStatus, recommendations } = getHMPIClassification(hmpiScore);

  return {
    metals,
    hmpiScore,
    pollutionLevel,
    safetyStatus,
    recommendations
  };
}

function getHMPIClassification(hmpiScore: number) {
  if (hmpiScore < 25) {
    return {
      pollutionLevel: 'No pollution',
      safetyStatus: 'Safe for drinking',
      recommendations: [
        'Normal chlorination & disinfection',
        'Suitable for drinking, domestic use, irrigation, food processing, pharmaceuticals'
      ]
    };
  } else if (hmpiScore < 50) {
    return {
      pollutionLevel: 'Low pollution',
      safetyStatus: 'Generally safe (monitoring needed)',
      recommendations: [
        'Regular monitoring required',
        'Simple filtration/UV treatment recommended',
        'Suitable for drinking (with caution), irrigation, agriculture, textile & beverage industries'
      ]
    };
  } else if (hmpiScore < 75) {
    return {
      pollutionLevel: 'Medium pollution',
      safetyStatus: 'Not preferable for drinking',
      recommendations: [
        'Advanced filtration required (RO, activated carbon, ion exchange)',
        'Suitable for irrigation, livestock, textile dyeing, paper & pulp industries'
      ]
    };
  } else if (hmpiScore < 100) {
    return {
      pollutionLevel: 'High pollution',
      safetyStatus: 'Unsafe for drinking',
      recommendations: [
        'Heavy metal removal required (RO, electrocoagulation, nanofiltration)',
        'Suitable for irrigation (non-edible crops), cooling in thermal plants, leather tanning, mining industries'
      ]
    };
  } else if (hmpiScore < 150) {
    return {
      pollutionLevel: 'Critical pollution',
      safetyStatus: 'Completely unsafe for drinking',
      recommendations: [
        'Strict restriction - only for non-contact purposes',
        'Advanced heavy metal removal (RO, nanofiltration, electrocoagulation)',
        'Suitable for non-food crop irrigation, cement/construction industries, chemical & metallurgy industries'
      ]
    };
  } else if (hmpiScore < 175) {
    return {
      pollutionLevel: 'Very Critical pollution',
      safetyStatus: 'Completely unsafe',
      recommendations: [
        'Treatment highly costly - not practical for potable use',
        'Suitable for cement production, metallurgy, mining, chemical industries'
      ]
    };
  } else if (hmpiScore < 200) {
    return {
      pollutionLevel: 'Extremely Critical pollution',
      safetyStatus: 'Completely unsafe',
      recommendations: [
        'Industrial-grade heavy metal recovery only',
        'Suitable for heavy industries such as smelting, ore processing, dye manufacturing',
        'Not suitable for agriculture or livestock'
      ]
    };
  } else {
    return {
      pollutionLevel: 'Toxic Waste Zone',
      safetyStatus: 'Absolutely unsafe',
      recommendations: [
        'No feasible treatment for safe water supply',
        'Considered hazardous wastewater',
        'Usable only in metallurgy, cement, chemical, and construction industries'
      ]
    };
  }
}
